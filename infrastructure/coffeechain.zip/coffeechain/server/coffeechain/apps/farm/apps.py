from django.apps import AppConfig


class FarmConfig(AppConfig):
    name = 'farm'
