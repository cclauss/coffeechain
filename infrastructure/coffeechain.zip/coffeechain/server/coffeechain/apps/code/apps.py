from django.apps import AppConfig


class CodeConfig(AppConfig):
    name = 'code'
