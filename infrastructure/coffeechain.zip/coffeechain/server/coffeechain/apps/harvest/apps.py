from django.apps import AppConfig


class HarvestConfig(AppConfig):
    name = 'harvest'
