from django.apps import AppConfig


class ShipmentConfig(AppConfig):
    name = 'shipment'
