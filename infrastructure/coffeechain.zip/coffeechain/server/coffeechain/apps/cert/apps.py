from django.apps import AppConfig


class CertConfig(AppConfig):
    name = 'cert'
