from django.apps import AppConfig


class RoastConfig(AppConfig):
    name = 'roast'
