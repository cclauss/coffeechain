import arrow
while True:
    print(arrow.utcnow())